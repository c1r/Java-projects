package ece325_lab_assignment3;
/**
Guitar is-a Instrument hence it extends the class Instrument
 */

public class Guitar extends Instrument {
	//instance variable just to output the type of Equipment
	private String guitar;

	//Taking info. to see if guitars needs wrapping
	public Guitar(boolean needsWrapping) {
		super(needsWrapping);
		this.guitar = "guitar";
	}

	@Override
	public String toString() {
		return guitar;
	}

}
