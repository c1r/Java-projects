//------------------------------------
// Name : Nidal Naseem
// Student ID: 1635297
// Fall '21, ECE 325 Lab Assignment 4
//
//------------------------------------




package ece325_lab_assignment4;

public class ZooShow {

	public static void main(String[] args) throws NotPlayingException {
		// create the artist
		Artist artist = new Artist();
		// create the zoo
		Zoo zoo = new Zoo();

		// while there are animals that still need feeding,
		while(!zoo.allAnimalsFed()) {
			// randomly select an animal from the zoo
			ZooAnimal animal = zoo.getRandomAnimalToComeToStage();
			try {
				// feed it 
				artist.feed(animal);

			}
			catch(NotPlayingException n) {
				//starting to play after first animal comes asking for food
				System.out.println("Band has not started playing yet");
				artist.startPlaying();
			}

			catch(AlreadyFedException a) {
				//printing when an already fed animal comes asking for food
				System.err.println(animal.getName() + " was already fed today"); 
			}
		}

		// stop playing when all animals are fed
		artist.stopPlaying();		
	}
}
