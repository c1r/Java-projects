package ece325_lab_assignment6;

public class CompareLargeStringConcatenation {
	/**
	 * Creates a String object, performs concatOperations operations on it and returns the resulting String.
	 * @param concatOperations The number of concatenation operations to perform on the String.
	 * @return The resulting String.
	 */


	private static String concatString(int concatOperations) {
		String finalString = "";
		//concatenating for every number of operations passed
		for (int i=0; i<concatOperations; i++) {
			finalString = finalString + "test";
		}
		return finalString;
	}

	/**
	 * Creates a StringBuilder object, performs concatOperations operations on it, converts the StringBuilder to a String and returns the 
	 * resulting String.
	 * @param concatOperations The number of concatenation operations to perform on the StringBuilder.
	 * @return The resulting String.
	 */


	private static String concatStringBuilder(int concatOperations) {
		StringBuilder strBuilder = new StringBuilder();
		//appending for every number of operations passed
		for (int i=0; i<concatOperations; i++) {
			strBuilder.append("test");
		}
		return strBuilder.toString();

	}

	public static void main(String[] args) {

		//looping through to pass the desired arguments for testing strConcat
		MillisPerformanceMeasurement measurePerformance = new MillisPerformanceMeasurement();
		for(int i=10; i<100001; i=i*10) {
			measurePerformance.start();
			CompareLargeStringConcatenation.concatString(i);
			measurePerformance.end();
			System.out.println(i +" " + measurePerformance.getResult());

		}
		System.out.println("\n");
		//looping through to pass the desired arguments for testing strBuilder

		for(int i =10; i<100001; i=i*10) {
			measurePerformance.start();
			CompareLargeStringConcatenation.concatStringBuilder(i);
			measurePerformance.end();
			System.out.print(i +" "+measurePerformance.getResult()+"\n");
		}	
	}
}

