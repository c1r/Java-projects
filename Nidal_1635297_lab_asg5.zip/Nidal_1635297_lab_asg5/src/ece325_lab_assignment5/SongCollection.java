package ece325_lab_assignment5;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.TreeSet;

/**
 * This class represents a Song. A Song has a title, release date, and a popularity score.
 * You are not allowed to change the code that is in between the indications, but you are allowed to add
 * code before and after the indicated lines.
 * 
 * @author Cor-Paul Bezemer
 *
 */
public class SongCollection {
	// not allowed to change anything after this until the indicated line
	private TreeSet<Song> collection;

	public SongCollection() {
		collection = new TreeSet<Song>();
	}

	public static LocalDate parseLocalDate(String str) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return LocalDate.parse(str, formatter);
	}

	public void addSong(Song s) {
		collection.add(s);
	}	

	public String toString() {
		String str = "[SongCollection: " + collection.size() + " songs: \n";
		for(Song s : collection) {
			str += "\t" + s + "\n";
		}
		return str + "]";
	}

	// you are allowed to make changes/add code after this

	public void loadSongs(String filename) {
		try {
			//Creating a buffered stream for faster reading from file for the
			//the scanner
			BufferedReader in = new BufferedReader(new FileReader(filename));
			Scanner read = new Scanner(in);


			//Tokens are delimited by a comma and a new line, else
			// we would have title of the next line clubbed with the 
			//release of the previous line
			read.useDelimiter(",|\n");
			String title, noOfPlays, date;
			int popularity;
			LocalDate releaseDate;

			while(read.hasNext())
			{
				try {
					//taking in the token to their respective field and parsing them
					//to their actual intended type

					title = read.next();

					noOfPlays = read.next();
					popularity = Integer.parseInt(noOfPlays);

					date = read.next();
					releaseDate = parseLocalDate(date);

					Song s = new Song(title, releaseDate,  popularity);
					addSong(s);

				}
				//With these catches we intend to ignore all lines with errors in
				//their formatting or lines with missing fields

				//ignoring the line with an incorrect popularity score
				catch (NumberFormatException f) {
					read.nextLine();
				}

				//ignoring the line with an incorrect date
				catch (DateTimeParseException e){
					read.nextLine();
					//continue;
				}

				//to break when the lines are empty after an exception is raised and caught
				catch (NoSuchElementException g) {
					break;

				}

			}

			read.close();
			in.close();

		}

		catch (IOException e) {
			System.err.println("Error while loading the " + filename );

		}
	}


	public List<Song> sort(Comparator<Song> comp) {
		//passing existing elements of the TreeSet to a new list
		//that will sort songs based on the popularity with the help of a 
		//comparator

		List<Song> songList = new ArrayList<Song> (collection);
		Collections.sort(songList, comp);
		return songList;
	}


	public static void main(String[] args) {
		SongCollection songcollection = new SongCollection();

		songcollection.loadSongs("songs.txt");
		System.out.println(songcollection.toString());

		Comparator<Song> sng = new SongComparator();
		System.out.println(songcollection.sort(sng));

	}
}
