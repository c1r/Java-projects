package ece325_lab_assignment5;

/* This implementation allows us to sort the songs on the basis of their popularity
 * in the descending order*/
public class SongComparator implements java.util.Comparator<Song> {

	@Override
	public int compare(Song s1, Song s2) {
		int i = Integer.compare(s2.getPopularity(),s1.getPopularity());
		return i;
	}
}
