package ece325_lab_assignment3;

/**
   Microphone is-a Instrument hence it extends the class Instrument
 */
public class Microphone extends Instrument {
	//instance variable just to output the type of Equipment
	private String microphone;

	//Taking info. to see if microphones needs wrapping
	public Microphone(boolean needsWrapping) {
		super(needsWrapping);
		this.microphone = "microphone";
	}

	@Override
	public String toString() {
		return microphone;
	}



}