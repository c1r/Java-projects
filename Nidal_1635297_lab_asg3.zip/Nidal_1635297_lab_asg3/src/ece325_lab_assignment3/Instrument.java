package ece325_lab_assignment3;

/**
All Instruments are Equipment hence it extends the class Equipment
 */
public abstract class Instrument extends Equipment {

	public Instrument(boolean needsWrapping) {
		//Taking info. to see if chairs needs wrapping
		super(needsWrapping);
	}

	@Override
	public abstract String toString();

}
