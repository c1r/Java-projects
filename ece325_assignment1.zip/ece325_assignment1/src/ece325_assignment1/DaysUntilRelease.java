package ece325_assignment1;

public class DaysUntilRelease {
	
	/**
	 * 	Calculate the number of days until releaseDate.
	 * @param releaseDate in the format yyyy-mm-dd (e.g., 2021-09-09)
	 * @return
	 */
	int calculateDaysUntilRelease(String releaseDate){
	
	}
	
	public static void main(String[] args) {

	}
}
