//----------------------------------------------
//
// Name: Nidal Naseem
// Student ID: 1635397
// Fall '21, ECE 325 Lab Assignment 3
//

//-----------------------------------------------


package ece325_lab_assignment3;

import java.util.ArrayList;

public class EquipmentInventory {
	// your inventory of items
	ArrayList<InventoryItem> inventory;


	public EquipmentInventory() {
		inventory= new ArrayList<InventoryItem>();		
	}

	/**
	 * Stow equipment into the trunk of the bus. Note: every type of equipment
	 * should only occur once in the inventory. Make sure to check if you are not
	 * accidentally taking someone else's equipment.
	 * 
	 * @param equip  The type of equipment to stow
	 * @param number The number of items to stow
	 */
	public void addEquipmentToBus(Equipment equip, int number) {
		//iterating through our arrayList to find the particular type of equipment
		//that is same as the parameter equip
		for(int i=0;i<inventory.size();i++) {
			//comparing their type using overridden equals
			if(inventory.get(i).getEquipment().equals(equip)) {
				inventory.get(i).addToBus(number);
				break;
			}
		}
	}

	/**
	 * Add equipment to your inventory. Note: every type of equipment
	 * should only occur once in the inventory. Whenever you acquire new
	 * equipment, it is always outside the bus. 
	 * 
	 * @param equip  The type of equipment to add to your inventory
	 * @param number The number of items to add
	 */
	public void addEquipmentToInventory(Equipment equip, int number) {
		//flag to indicate the equipment type is not present in the inventory
		boolean flag = true;
		//adding to inventory if the equipment type is already present in the inventory
		for(int i=0;i<inventory.size();i++) {
			if(inventory.get(i).getEquipment().equals(equip)) {
				inventory.get(i).addToInventory(number);
				flag = false;				
			}
		}
		if (flag) {
			//if equipment type not present in inventory, it is added as a new item
			InventoryItem Inv = new InventoryItem(equip, number);
			Inv.addToBus(0);
			inventory.add(Inv);

		}
	}

	/**
	 * Returns a list of items that are still missing from the bus. 
	 * @return List of missing items.
	 */
	public ArrayList<InventoryItem> getMissingItems() {
		ArrayList<InventoryItem> missing;
		missing = new ArrayList<InventoryItem>();

		//iterating through all types of equipment to check for items in inventory and items in bus
		for(int i=0; i<inventory.size();i++ ) {
			int inBus = inventory.get(i).getInBus();
			int inInventory = inventory.get(i).getInInventory();
			if(inBus<inInventory){
				//if items in inventory were more than items in bus, the remaining items (type and number) were added to missing
				InventoryItem miss = new InventoryItem(inventory.get(i).getEquipment(),inInventory-inBus);
				missing.add(miss);
			}
		}
		return missing;



	}

	/**
	 * Returns a list of items that still need wrapping. Note that these items might still 
	 * be (partially) missing from the bus too. 
	 * @return List of items that still need to be wrapped.
	 */
	public ArrayList<InventoryItem> getNeedsWrappingItems() {
		//new arrayList with items that are not wrapped is initialized
		ArrayList<InventoryItem> notWrapped;
		notWrapped = new ArrayList<InventoryItem>();

		//iterating through our inventory to check if an item needs Wrapping and adding those items to our new Arraylist 
		for(int i=0; i<inventory.size();i++) {
			if(inventory.get(i).needsWrapping()) {			
				notWrapped.add(new InventoryItem(inventory.get(i).getEquipment(),inventory.get(i).getInInventory()));
			}
		}

		return notWrapped;
	}

	/**
	 * Wrap items of the same type as e.
	 * @param The type of equipment you want to wrap. 
	 */
	public void wrapItems(Equipment e) {

		for (int i=0;i<inventory.size();i++) {
			//checking for items of the same type as e and getting them wrapped
			if(inventory.get(i).getEquipment().equals(e)) {
				inventory.get(i).wrap();
			}
		}
	}

	/** 
	 * Returns a string representation of the inventory.
	 */
	public String toString() {
		String str ="";
		for(int i = 0; i < inventory.size(); i++) {
			str += "Item: "+ inventory.get(i).getEquipment() + ", in Inventory: " + inventory.get(i).getInInventory() +", in Bus: "+inventory.get(i).getInBus();
			if((inventory.get(i).needsWrapping())) {
				str += ", Needs Wrapping \n";
			}
			else {
				str += "\n";
			}
		}
		return str;


	}

	/** 
	 * Returns true iff the inventory is complete, wrapped and you are ready to go.
	 * @return true iff inventory is complete and wrapped
	 */
	public boolean getReadyToGo() {
		for(int i = 0; i<inventory.size();i++) {
			//checking if any of item still needs wrapping and checking their number inBus is same as the number in inInventory
			if((inventory.get(i).needsWrapping() || (inventory.get(i).getInBus()!=inventory.get(i).getInInventory())))
				return false;
		}
		return true;
	}

	public static void main(String[] args) {

		EquipmentInventory myInv = new EquipmentInventory();
		Microphone mics = new Microphone(true);
		myInv.addEquipmentToInventory(mics,2);
		Guitar guitars = new Guitar(true);
		myInv.addEquipmentToInventory(guitars,4);
		Equipment chairs = new Chair(false);
		myInv.addEquipmentToInventory(chairs, 12);

		//Add 2 microphones, 4 guitars and 12 chairs to Equipment Inventory

		/*
		 * Fill out code here - done
		 */

		System.out.println(myInv);

		System.out.println("Printing missing items: ");
		ArrayList<InventoryItem> missing = myInv.getMissingItems();
		System.out.println(missing);

		System.out.println("Printing items that need wrapping: ");
		ArrayList<InventoryItem> needsWrapping = myInv.getNeedsWrappingItems();
		System.out.println(needsWrapping);
		myInv.addEquipmentToBus(chairs, 15);
		//Try to add 15 chairs to bus

		/*
		 * Fill out code here - done
		 */

		System.out.println(myInv);

		System.out.println(myInv.getReadyToGo());
		myInv.addEquipmentToBus(mics, 2);
		myInv.addEquipmentToBus(guitars, 4);

		//Try to add 4 guitars and 2 microphones to bus

		/*
		 * Fill out code here - done
		 */
		System.out.println(myInv.getReadyToGo());

		//Wrap items that need wrapping but have not been wrapped yet
		for (int i=0;i<needsWrapping.size();i++) {
			myInv.wrapItems(needsWrapping.get(i).getEquipment());
		};


		/*
		 * Fill out code here - done
		 */

		System.out.println(myInv.getReadyToGo());

	}
}
