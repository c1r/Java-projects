package ece325_lab_assignment6;

public class CompareManySmallStringsConcatenation {
	/**
	 * Creates numberOfStrings String objects and performs operationsPerString concatenation
	 * operations on every string. Note that you can create one string first, then perform all
	 * the operations on that string, then create the second string, etc.
	 * @param numberOfStrings
	 * @param operationsPerString
	 */
	private static void concatString(int numberOfStrings, int concatOperationsPerString) {
		for(int i=0; i<numberOfStrings; i++) {
			String str = "";
			for(int j=0; j<concatOperationsPerString; j++) {
				str = str + "test";
			}			
		}
	}

	/**
	 * Creates numberOfStrings StringBuilder objects and performs operationsPerString concatenation
	 * operations on every StringBuilder. Note that you can create one StringBuilder first, then 
	 * perform all the operations on that StringBuilder, then convert the StringBuilder to a String, 
	 * then create the second StringBuilder, etc.
	 * @param numberOfStrings
	 * @param operationsPerString
	 */
	private static void concatStringBuilder(int numberOfStrings, int concatOperationsPerString) {
		for(int i=0; i<numberOfStrings; i++) {
			StringBuilder strBuilder = new StringBuilder();
			for(int j=0; j<concatOperationsPerString; j++) {
				strBuilder.append("test");
			}
			strBuilder.toString();
		}
	}

	public static void main(String[] args) {
		MillisPerformanceMeasurement measurePerformance = new MillisPerformanceMeasurement();
		for(int i=1000; i<100_000_001; i=i*10) {
			for(int j=0; j<5; j++) {
				measurePerformance.start();
				CompareManySmallStringsConcatenation.concatString(i,j);
				measurePerformance.end();
				System.out.println(i +" " +j+ " "+ measurePerformance.getResult());
			}			

		}
		System.out.println("\n");	

		for(int i=1000; i<100_000_001; i=i*10) {
			for(int j=0; j<5; j++) {
				measurePerformance.start();
				CompareManySmallStringsConcatenation.concatStringBuilder(i, j);
				measurePerformance.end();
				System.out.println(i +" " +j+ " "+ measurePerformance.getResult());
			}			

		}		
	}
}