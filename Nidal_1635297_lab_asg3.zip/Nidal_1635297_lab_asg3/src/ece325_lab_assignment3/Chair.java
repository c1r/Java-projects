package ece325_lab_assignment3;
/**
Chair is-an Equipment hence it extends the class Equipment
 */

public class Chair extends Equipment {
	//instance variable just to output the type of Equipment
	private String chair;

	public Chair(boolean needsWrapping) {
		//Taking info. to see if chairs needs wrapping
		super(needsWrapping);
		this.chair = "chair";
	}

	@Override
	public String toString() {
		return chair;
	}

}
