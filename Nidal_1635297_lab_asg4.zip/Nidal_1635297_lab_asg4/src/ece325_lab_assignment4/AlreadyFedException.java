package ece325_lab_assignment4;

//This is a custom unchecked Exception extending RuntimeException, which is used
//to output an error for animals asking to be fed again

//If a client cannot do anything to recover from the exception, make it an unchecked exception.
//Here, client being the band.

//This should be an unchecked exception as there's almost nothing 
//that the band can do to prevent the same animal from asking to be fed again
//other than report to zoo manager (system.err)
public class AlreadyFedException extends RuntimeException{

	public AlreadyFedException(String message) {
		super(message);
	}
}