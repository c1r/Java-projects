package ece325_assignment4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestSalary {

	@Test
	void testNullParameters() {
		//test cases for when null is passed
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(1000D,null,10);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(null,100D,10);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(1000D,100D,null);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(null,null,null);});
	}

	@Test
	void testNegParameters() {
		//test cases for when a negative number is passed
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(-1000D,100D,10);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(1000D,-100D,10);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(1000D,100D,-10);});
	}

	@Test
	void testbaseSalaryabove1000() {
		//test cases for when salary is above 1000
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(10000D,100D,10);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(1000.0005D,100D,10);});
	}

	@Test
	void testSnackAmountaboveBaseSalary() {
		//test cases for when amount spent on snacks is higher than base salary
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(100D,1000D,10);});
		assertEquals(100,Salary.pay(1000D, 1000D, 10));
	}

	@Test
	void testBonusabove10() {
		//test case when bonus is greater than 10
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(1000D,100D,15);});
	}

	@Test
	void testSalary() {
		//general regression testing
		assertEquals(910, Salary.pay(1000D,100D,1),0.001D);
		assertEquals(790, Salary.pay(900D, 200D, 10),0.001D);
	}

	@Test
	void testsalarydoubledelta() {
		//Checks if delta works as intended
		assertEquals(1040.811088, Salary.pay(955.8888888888D,10.66669D,10),0.001D);
		assertEquals(112.3456, Salary.pay(123.456789D,12.3456789D,1),0.001D);
	}

	@Test
	void testZeroSalary() {		
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(0D, 200D, 10);});
		assertEquals(0,Salary.pay(0D, 0D, 0));
	}

	@Test
	void testDoubleMax() {
		//test cases when MAX_VALUE of each type is passed
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(Double.MAX_VALUE,100D,10);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(Double.MAX_VALUE,Double.MAX_VALUE-1000,10);});
		assertThrows(IllegalArgumentException.class, () -> {Salary.pay(Double.MAX_VALUE, Double.MAX_VALUE, Integer.MAX_VALUE);});
	}

}
