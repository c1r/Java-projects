package ece325_lab_assignment4;

//This is a custom checked Exception extending Exception, which is used
//to avoid feeding the animals when the band has not started playing

//We know the Rule is if a client can reasonably be expected to recover from an exception,
//make it a checked exception - in this case the client being the band

//This should be a checked exception as the Band can/should start playing as
// soon as an animal approaches them for food. Thus, this is an exception that 
// has to be handled mandatorily

public class NotPlayingException extends Exception{

	public NotPlayingException(String message) {
		super(message);
	}
}