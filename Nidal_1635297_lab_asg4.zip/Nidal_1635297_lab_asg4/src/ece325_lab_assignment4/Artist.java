package ece325_lab_assignment4;

/**
 * The artist/band that is performing. You must finish this class.
 * @author corpaul
 *
 */
public class Artist implements ZooPerformer {
	/** 
	 * Indicates whether the artist is currently playing (= performing). 
	 */
	private boolean isPlaying;

	public Artist() {
		isPlaying = false;
	}

	/** 
	 * Feed the animal. Make sure to check whether we are allowed to feed this animal,
	 * and make sure to handle things correctly if we are not allowed to feed it. You are allowed
	 * to change this method's signature, if necessary.
	 * @throws NotPlayingException 
	 * @throws AlreadyFedException 
	 * 
	 */
	public void feed(ZooAnimal animal) throws NotPlayingException {
		//throws NotPlaying if haven't started playing
		if(isPlaying == false) {			
			throw new NotPlayingException("Not Playing");
		}

		else {
			//throws AlreadyFedException if the animal has already been fed
			if(animal.isFedAlready() == true) {
				throw new AlreadyFedException("Already Fed");
			}
			//otherwise feed the animal
			else {
				animal.feed();
			}
		}
	}


	/**
	 * Sometimes, artists get distracted, so there is a 50% chance that they start
	 * playing when you call this method. 
	 * 
	 */
	public void startPlaying() {
		//accounting for the 50% chance of starting to play
		double r = Math.random();
		if(r < 0.5) {
			isPlaying = true; 
			System.out.println("Band has started playing");
		}

		else {
			System.out.println("Sorry, got distracted");
		}
	}

	public void stopPlaying() {
		//setting isPlaying to false
		isPlaying = false;
		System.out.println("Band has stopped playing");
	}

}
